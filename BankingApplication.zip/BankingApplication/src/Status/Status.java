package Status;

public enum Status {
	SUCCESS,FAILURE;

}
