package Entities;

public enum TransactionType {
	withdraw,deposit;
}
